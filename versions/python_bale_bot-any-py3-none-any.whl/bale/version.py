__version__ = '2.5.0'
BALE_API_BASE_URL = 'https://tapi.bale.ai/bot'
BALE_API_FILE_URL = 'https://tapi.bale.ai/file/bot'
BALE_API_VERSION = '2.0.0'
